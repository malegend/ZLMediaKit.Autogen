感谢[big panda](<2381267071@qq.com>) 开发并贡献此webrtc js测试客户端,
其开源项目地址为：https://gitee.com/xiongguangjie/zlmrtcclient.js